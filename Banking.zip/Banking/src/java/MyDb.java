
import java.sql.Connection;
import java.sql.DriverManager;

public class MyDb {

    Connection con;

    public Connection getCon() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank", "root", "1234");
        } catch (Exception ex) {

        }
        return con;
    }
}
